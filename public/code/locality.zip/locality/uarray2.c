/*
 *      uarray2.c
 *      by Saad Mazhar and Jarod Gowgiel
 *      Homework 2 Part A: UArray 2
 *      Last modified 9/26/17
 *      
 *      This implementation uses the pre-existing UArray data structure to 
 *      represent a two dimensional UArray. We have chosen to implement this
 *      as a single UArray, with the 2D structure being linearized to allow
 *      for constant time access.
 */


#include <stdio.h>
#include <stdlib.h>
#include <except.h>
#include <uarray.h>
#include "uarray2.h"
#include "assert.h"

Except_T Mem_Failed;

struct UArray2_T  {
        int rows;
        int cols;
        int size;
        UArray_T uarray;
};

/* 
 * Purpose: To allocate a new unboxed 2D array with the given dimensions and
 *          of the given size per index
 */
UArray2_T UArray2_new(int num_cols, int num_rows, int new_size)
{
        /* Create a new UArray and UArray2 */
        UArray_T new_uarray;
        struct UArray2_T *new_uarray2 = malloc(sizeof(struct UArray2_T));

        TRY
                new_uarray = UArray_new(num_cols * num_rows, new_size);
        EXCEPT(Mem_Failed)
                fprintf(stderr, "ERROR: Memory allocation failed\n");
                exit(EXIT_FAILURE);
        END_TRY;

        /* Ensures there are no errors */
        assert(new_uarray2 != NULL);
        assert(num_cols > 0 && num_rows > 0);
        assert(new_size > 0);

        /* Set the variables for the UArray_2 using the given data */
        new_uarray2 -> cols = num_cols;
        new_uarray2 -> rows = num_rows;
        new_uarray2 -> size = new_size; 
        new_uarray2 -> uarray = new_uarray;

        return new_uarray2;
}


/* Purpose: To free the memory associate with the given unboxed array */
void UArray2_free(UArray2_T *UArray2)
{
        assert(UArray2 && *UArray2);
        
        UArray_T *free_array = &((*UArray2) -> uarray);
        
        UArray_free(free_array);
        free(*UArray2);
        
        return;
}

/* Purpose: To return the width of the given unboxed array */
int UArray2_width(UArray2_T UArray2)
{
        assert(UArray2);
        return UArray2 -> cols;
}

/* Purpose: To return the height of the give unboxed array */
int UArray2_height(UArray2_T UArray2)
{
        assert(UArray2);
        return UArray2 -> rows;
}

/* Purpose: To return the size of each index in the unboxed array */
int UArray2_size(UArray2_T UArray2)
{
        assert(UArray2);
        return UArray2 -> size;
}

/* 
 * Purpose: To return a pointer to the value at [row, col] in the given
 *          unboxed array
 */
void *UArray2_at(UArray2_T UArray2, int col, int row)
{
        assert(UArray2);
        if (col < 0 && col >= UArray2_width(UArray2)){
                throw_error("ERROR: Index out of bounds");
        }

        if(row < 0 && row >= UArray2_height(UArray2)) {
                throw_error("ERROR: Index out of bounds");
        }
        /* The value at col, row is found at [(col * num_rows) + row]. The 
         * values from the first column are placed in memory first, then the 
           second, and so on. */
        int num_rows = UArray2_height(UArray2);
        return UArray_at((UArray2 -> uarray), (col * num_rows) + row);
}

/*
 * Purpose: To call the given function on every value in the given unboxed
 *          array starting with all the values in the first column, then the
 *          second, etc.
 */
void UArray2_map_col_major(UArray2_T UArray2, void apply(int row, int col,
                                                 UArray2_T UArray2, void *p1,
                                                 void *p2), void *cl)
{
        assert(UArray2);
        /* Loop through each row in the first column, then each row in the 
           next column, etc. */
        for (int curr_col = 0; curr_col < UArray2_width(UArray2); 
                 curr_col++) {
                for (int curr_row = 0; curr_row < UArray2_height(UArray2); 
                         curr_row++) {
                        void *value = UArray2_at(UArray2, curr_col, curr_row);
                        apply(curr_col, curr_row, UArray2, value, cl);
                }
        }
        return;
}

/* 
 * Purpose: Functions the same as map_col_major, except that the values that
 *          are mapped begin with every value in the first row, and then the
 *          second row, etc.
 */
void UArray2_map_row_major(UArray2_T UArray2, void apply(int row, int col,
                                                 UArray2_T UArray2, void *p1,
                                                 void *p2), void *cl)
{
        assert(UArray2);
        /* Loop through each column in the first row, then each column in the
           next row, etc. */
        for (int curr_row = 0; curr_row < UArray2_height(UArray2); 
                 curr_row++) {
                for (int curr_col = 0; curr_col < UArray2_width(UArray2);
                         curr_col++) {
                        void *value = UArray2_at(UArray2, curr_col, curr_row);
                        apply(curr_col, curr_row, UArray2, value, cl);
                }
        }
        return;
}

/* Purpose: To raise a Hanson error with the given error message */
void throw_error(char *error_msg) 
{
        struct Except_T error;
        error.reason = error_msg;
        RAISE(error);
        exit(EXIT_FAILURE);
}

