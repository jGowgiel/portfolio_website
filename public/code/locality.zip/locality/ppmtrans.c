/*
 *     uarray2.c
 *     by Darcy Hinck and Jarod Gowgiel
 *     Homework 3 Part C: ppmtrans
 *
 *     Summary: This program takes a given pnm file and performs a rotation
 *              on it according to the provided command line arguments. As an
 *              optional paramter, this program can also be given a mapping
 *              scheme to use, which will affect the data structure that is 
 *              used. It is also capable of creating accurate timing data for 
 *              each operation.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "except.h"
#include "assert.h"
#include "a2methods.h"
#include "a2plain.h"
#include "a2blocked.h"
#include "pnm.h"
#include "cputiming.h"

#define SET_METHODS(METHODS, MAP, WHAT) do {                    \
        methods = (METHODS);                                    \
        assert(methods != NULL);                                \
        map = methods->MAP;                                     \
        if (map == NULL) {                                      \
                fprintf(stderr, "%s does not support "          \
                                WHAT "mapping\n",               \
                                argv[0]);                       \
                exit(1);                                        \
        }                                                       \
} while (0)

static void
usage(const char *progname)
{
        fprintf(stderr, "Usage: %s [-rotate <angle>] "
                        "[-{row,col,block}-major] [filename]\n",
                        progname);
        exit(1);
}

/* Minor declarations */
void raise_error(char *filename);

/* Major functions - call everything below this */
FILE *open_file(char *filename);
Pnm_ppm import_ppm_to_array(FILE *input, A2Methods_T methods);
void modify_image(Pnm_ppm original_image, int rotation, A2Methods_mapfun *map);
void display_image(Pnm_ppm modified_image);
void time_operations(Pnm_ppm original_image, int rotation, 
                     A2Methods_mapfun *map, char *filename, char *map_type);


/* The corresponding apply functions for each rotation */
void apply_rotate_zero(int col, int row, A2Methods_UArray2 array2, void *elem,
                       void *cl);
void apply_rotate_ninety(int col, int row, A2Methods_UArray2 array2, 
                         void *elem, void *cl);
void apply_rotate_one_eighty(int col, int row, A2Methods_UArray2 array2, 
                             void *elem, void *cl);

void rotate_amount(Pnm_ppm original_image, A2Methods_mapfun *map, 
                   int image_width, int image_height,
                   void rotate_func(int col, int row, A2Methods_UArray2 array2, 
                   void *elem, void *cl));


int main(int argc, char *argv[]) 
{
        /* Allocate the needed variables */
        char *time_file_name = NULL;
        int   rotation       = 0;
        int   i;
        char *filename = NULL;
        char *mapping_type = NULL;
        FILE *input;
        Pnm_ppm original_image;

        /* default to UArray2 methods */
        A2Methods_T methods = uarray2_methods_plain;
        assert(methods);

        /* default to best map */
        A2Methods_mapfun *map = methods->map_default;
        assert(map);

        /* Loops through arguments 1 and 2 and selects proper options in
         * the variables above */
        for (i = 1; i < argc; i++) {
                if (strcmp(argv[i], "-row-major") == 0) {
                        SET_METHODS(uarray2_methods_plain, map_row_major,
                                    "row-major");
                        mapping_type = "row-major";
                } else if (strcmp(argv[i], "-col-major") == 0) {
                        SET_METHODS(uarray2_methods_plain, map_col_major,
                                    "column-major");
                        mapping_type = "col-major";

                } else if (strcmp(argv[i], "-block-major") == 0) {
                        SET_METHODS(uarray2_methods_blocked, map_block_major,
                                    "block-major");
                         mapping_type = "block-major";
                } else if (strcmp(argv[i], "-rotate") == 0) {
                        if (!(i + 1 < argc)) {      /* no rotate value */
                                usage(argv[0]);
                        }
                        char *endptr;
                        rotation = strtol(argv[++i], &endptr, 10);
                        if (!(rotation == 0 || rotation == 90 ||
                            rotation == 180 || rotation == 270)) {
                                fprintf(stderr, 
                                        "Rotation must be 0, 90 180 or 270\n");
                                usage(argv[0]);
                        }
                        if (!(*endptr == '\0')) {    /* Not a number */
                                usage(argv[0]);
                        }
                } else if (strcmp(argv[i], "-time") == 0) {
                        time_file_name = argv[++i];
                } else if (*argv[i] == '-') {
                        fprintf(stderr, "%s: unknown option '%s'\n", argv[0],
                                argv[i]);
                        usage(argv[0]);
                } else if (argc - i > 1) {
                        fprintf(stderr, "Too many arguments\n");
                        usage(argv[0]);
                } else {
                        break;
                }
        }

        /* Check that the inputs have been implemented */
        if (!(rotation == 0 || rotation == 90 || rotation == 180)) {
                fprintf(stderr, 
                        "This amount of rotation has not been implemented!\n");
                exit(1);
        }

        /* Use the ternary operator to select either NULL for the filename, or
         * the given filename */
        filename = argv[i] ? argv[i] : NULL;
        
        input = open_file(filename);

        original_image = import_ppm_to_array(input, methods);

        /* If timing, run the timing code, otherwise don't */
        if (time_file_name != NULL) {
                time_operations(original_image, rotation, map, time_file_name, 
                                mapping_type);
        }
        else {
                modify_image(original_image, rotation, map);
        }

        (void)time_file_name;

        fclose(input);

        exit(EXIT_SUCCESS);
}

/*
 * Purpose: To rotate the given image by the given amount and output timing
 *          data to a file with the given name
 */
void time_operations(Pnm_ppm original_image, int rotation, 
                     A2Methods_mapfun *map, char *filename, char *map_type) 
{
        /* Initialize the timer and the needed variables */
        CPUTime_T timer = CPUTime_New();
        int total_pixels = (original_image -> height) * 
                            (original_image -> width);
        double time_used;

        /* Start the timer, modify the image, and then immediately stop it */
        CPUTime_Start(timer);
        modify_image(original_image, rotation, map);
        time_used = CPUTime_Stop(timer);        

        double time_per_pixel = time_used / total_pixels;

        FILE *output = fopen(filename, "a");

        /* Print descriptive output to the given file */
        fprintf(output, "Using %s mapping:\n", map_type);
        fprintf(output, "       Rotating the image by %d degrees took\n",
                        rotation);
        fprintf(output, "               %f nanoseconds total\n", time_used);
        fprintf(output, "               %f nanoseconds per pixel\n\n", 
                        time_per_pixel);
        
        fclose(output);
        CPUTime_Free(&timer);
}

/* 
 * Purpose: To open a file with the given name, or if NULL is given as the
 *          filename, from standard input 
 */
FILE *open_file(char *filename)
{
    FILE *input = NULL;

    /* If no filename is given, use stdin */
    if (filename == NULL) {
        input = stdin;
    }

    /* Open the given file, ensuring a valid filename */
    else {
        input = fopen(filename, "r");
        if (input == NULL) {
            /* Raises CRE and exits with code EXIT_FAILURE */
            raise_error("ERROR: given file could not be opened");
        }
    }
    return input;
}

/* 
 * Purpose: To use the given file pointer and methods to create a new Pnm_ppm
 *          instance using that file 
 */
Pnm_ppm import_ppm_to_array(FILE *input, A2Methods_T methods)
{
        
        /* Make sure that we are given an actual ppm file */
        Pnm_ppm new_reader = Pnm_ppmread(input, methods);
        assert(new_reader);

        return new_reader;
}

/*
 * Purpose: To use the given rotation amount and the given mapping function to
 *          rotate the given image the proper amount
 */
void modify_image(Pnm_ppm original_image, int rotation, A2Methods_mapfun *map)
{
       
        //const struct A2Methods_T *image_methods = (original_image -> methods);

        A2Methods_UArray2 original_pixels = original_image -> pixels;
        assert(original_pixels);

        int image_height = original_image -> height;
        int image_width = original_image -> width;

        if (rotation == 0) {
                rotate_amount(original_image, map, image_width, image_height,
                              apply_rotate_zero);
        }
        else if (rotation == 90) {
                rotate_amount(original_image, map, image_height, image_width,
                              apply_rotate_ninety);

        }
        else if (rotation == 180) {
                rotate_amount(original_image, map, image_width, image_height,
                              apply_rotate_one_eighty);
        }
}


/* Rotates an image by the defined call in modify_image (0, 90, or 180). 
 * Creates a new instance of the rotated image using malloc and asserts 
 * that the image is not NULL.
 */
void rotate_amount(Pnm_ppm original_image, A2Methods_mapfun *map, 
                   int image_width, int image_height,
                   void rotate_func(int col, int row, A2Methods_UArray2 array2, 
                   void *elem, void *cl))
{

        const struct A2Methods_T *image_methods = (original_image -> methods);

        A2Methods_UArray2 original_pixels = original_image -> pixels;
        assert(original_pixels);

        int original_denominator = original_image -> denominator;
        int pixel_size = image_methods -> size(original_pixels);

        /* Define a new UArray2 with the height and width switched */
        Pnm_ppm modified_image = malloc(sizeof(struct Pnm_ppm));
        assert(modified_image);

        modified_image->pixels = image_methods -> new(image_width, image_height,
                                                      pixel_size);

        /* Set the proper fields in this new, rotated Pnm_ppm */
        modified_image -> height = image_height;
        modified_image -> width = image_width;
        modified_image -> denominator = original_denominator;
        modified_image -> methods = image_methods;

        /* Call our mapping function */
        map(original_pixels, rotate_func, modified_image);

        /* Properly display the image */
        display_image(modified_image);

        /* Free the allocated memory */
        Pnm_ppmfree(&modified_image);
        Pnm_ppmfree(&original_image);

        return;
}


/*
 * Purpose: The apply function for rotate 0 - follows the required structure
 *          for an apply function such that it may be passed to a mapping
 *          function 
 */
void apply_rotate_zero(int col, int row, A2Methods_UArray2 array2, 
                         void *elem, void *cl)
{

        const struct A2Methods_T image_methods = (*((Pnm_ppm)cl) -> methods);

        /* Get a pointer to the proper index using the geometric formula we
         * were given */
        Pnm_rgb new_index_p = (Pnm_rgb)image_methods.at(((Pnm_ppm)cl) -> 
                               pixels, col, row);
        assert(new_index_p);

        /* Set the value of this new element */
        *new_index_p = *(Pnm_rgb)elem;
        (void)array2;
        return;

}


/*
 * Purpose: The apply function for rotate 0 - follows the required structure
 *          for an apply function such that it may be passed to a mapping
 *          function 
 */
void apply_rotate_ninety(int col, int row, A2Methods_UArray2 array2, 
                         void *elem, void *cl) {

        const struct A2Methods_T image_methods = (*((Pnm_ppm)cl) -> methods);

        /* Get a pointer to the proper index using the geometric formula we
         * were given */
        int array2_height = image_methods.height(array2);
        Pnm_rgb new_index_p = (Pnm_rgb)image_methods.at(((Pnm_ppm)cl) -> 
                               pixels, array2_height - row - 1, col);
        assert(new_index_p);

        /* Set the value of this new element */
        *new_index_p = *(Pnm_rgb)elem;

        return;

}


/*
 * Purpose: The apply function for rotate 0 - follows the required structure
 *          for an apply function such that it may be passed to a mapping
 *          function 
 */
void apply_rotate_one_eighty(int col, int row, A2Methods_UArray2 array2, 
                         void *elem, void *cl)
{

        const struct A2Methods_T image_methods = (*((Pnm_ppm)cl) -> methods);

        /* Get a pointer to the proper index using the geometric formula we
         * were given */
        int array2_height = image_methods.height(array2);
        int array2_width = image_methods.width(array2);
        Pnm_rgb new_index_p = (Pnm_rgb)image_methods.at(((Pnm_ppm)cl) -> 
                               pixels, (array2_width - col - 1), 
                               (array2_height - row - 1));
        assert(new_index_p);

        /* Set the value of this new element */
        *new_index_p = *(Pnm_rgb)elem;

        return;

}

/*
 * Purpose: To print out the given Pnm_ppm image
 */
void display_image(Pnm_ppm modified_image)
{
        Pnm_ppmwrite(stdout, modified_image);
        return;
}

/* 
 * Purpose: To raise an error with the given message 
 */
void raise_error(char *error_msg)
{
        struct Except_T error;
        error.reason = error_msg;
        RAISE(error);
        exit(EXIT_FAILURE);
}


