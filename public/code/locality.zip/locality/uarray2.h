/*
 *     	uarray2.h
 *     	by Saad Mazhar and Jarod Gowgiel
 *     	Homework 2 Part A: UArray2 Header File
 *      Last modified 9/26/17
 */

#ifndef UARRAY2_H
#define UARRAY2_H


/* The definition for this struct will be given in the .c file */
#define T UArray2_T
typedef struct T *T;

/*
 * Purpose: Creates a new unboxed 2D array with the given dimensions and
 *          of the given size per index.
 */
T UArray2_new(int width, int height, int size);

/* 
 * Purpose: To free the memory associate with the given unboxed 2D array.
 */
void UArray2_free(T *UArray2);

/*
 * Purpose: To return the height of the give unboxed 2D array.
 */
int UArray2_height(T UArray2);

/*
 * Purpose: To return the width of the given unboxed 2D array.
 */
int UArray2_width(T UArray2);

/*
 * Purpose: To return the size of each index in the given unboxed 2D array.
 */
int UArray2_size(T UArray2);

/*
 * Purpose: To return a pointer to the value at [row, col] in the given
 *          unboxed 2D array.
 */
void *UArray2_at(T UArray2, int row, int col);

/*
 * Purpose: To call the given function on every value in the given unboxed
 *          array starting with all the values in the first column, then the
 *          second, etc.
 */
void UArray2_map_col_major(T UArray2, void apply(int row, int col,
                                                 T UArray2, void *p1,
                                                 void *p2), void *cl);
/* 
 * Purpose: Functions the same as map_col_major, except that the values that
 *          are mapped begin with every value in the first row, and then the
 *          second row, etc.
 */
void UArray2_map_row_major(T UArray2, void apply(int row, int col,
                                                 T UArray2, void *p1,
                                                 void *p2), void *cl);

/* 
 * Purpose: To raise a Hanson error with the given error message.
 */
void throw_error(char *error_msg);

#undef T
#endif


