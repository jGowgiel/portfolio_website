/*
 *     compress.h
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module provides one function, which returns void and
 *              accepts a FILE stream from which a compressed image will be
 *              generated
 */



#ifndef COMPRESS_H
#define COMPRESS_H

extern void compress_image(FILE *input);


#endif
