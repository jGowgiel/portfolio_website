/*
 *     decompress.h
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module provides one function which accepts a file stream
 *              and prints a decompressed image using the information from
 *              this file
 */


#ifndef DECOMPRESS_H
#define DECOMPRESS_H


extern void decompress_image(FILE *input);


#endif
