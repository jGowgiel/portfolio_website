
#include <stdio.h>
#include <stdlib.h>
#include "compress.h"
#include "decompress.h"
#include "compress40.h"

void compress40(FILE *input)
{
        /* Start us off */
        compress_image(input);
}


void decompress40(FILE *input)
{
        /* Start us off */
        decompress_image(input);
}
