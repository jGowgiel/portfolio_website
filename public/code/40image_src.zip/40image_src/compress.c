/*
 *     compress.c
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: Given a file stream containing a Pnm_ppm, this module will
 *              pack the image into a series of code words (one for each 2x2 set of 
 *              pixels), and then print those code words to stdout
 */


#include <stdio.h>
#include <stdlib.h>
#include "seq.h"
#include "pnm.h"
#include "a2methods.h"

#include "a2plain.h"
#include "packer.h"
#include "compress.h"
#include "rgb_to_component.h"
#include "bitpack.h"
#include "assert.h"

Except_T Mem_Failed;

static const unsigned WORD_BYTES = 4;
static const unsigned TRIM_MULTIPLE = 2;

/* Single point of entry and output (should be the only public function) */
void compress_image(FILE *input)
{
        /* Define the methods that will be used */
        A2Methods_T methods = uarray2_methods_plain;

        /* Create a PNM instance */
        Pnm_ppm original_image = Pnm_ppmread(input, methods);

        /* Allocate the queue */
        Seq_T queue = NULL;

        TRY
                queue = Seq_new(original_image->width * 
                                           original_image->height);
                assert(queue);
        EXCEPT(Mem_Failed)
        END_TRY;

        /* Catch for small images */
        if (original_image->width > 1 && original_image->height > 1) {

                /* Convert the given Pnm_ppm with RGB pixels to component 
                 * video */
                Pnm_ppm_cv component_image = 
                        convert_to_component(original_image);

                /* Generate a queue of packed words */
                queue = pack_word(component_image, queue);

                /* Conditional memory management */
                (component_image)->methods->free(&((component_image)
                                                 ->cv_pixels));
                free(component_image);
        }
        
        /* Print the header */
        original_image -> width = (original_image->width) - 
                                  (original_image->width % TRIM_MULTIPLE);
        original_image -> height = (original_image->height) - 
                                  (original_image->height % TRIM_MULTIPLE);

        printf("COMP40 Compressed image format 2\n%u %u\n", 
                original_image->width, original_image->height);

        /* Step through the list and print the values therein in big endian */
        while (Seq_length(queue) > 0) {
                uint32_t *top_value = NULL;

                TRY
                        top_value = Seq_remlo(queue);
                EXCEPT(Mem_Failed)
                END_TRY;

                /* Print out the word in big endian order, printing individual
                 * bytes to stdout */
                for (int i = WORD_BYTES - 1; i >= 0; i--) {
                        putchar(Bitpack_getu(*top_value, 8, i * 8));
                }

                (void)top_value;
                free(top_value);
        }
        

        /* Unconditional memory management */
        Pnm_ppmfree(&original_image);

        Seq_free(&queue);

        return;
}


