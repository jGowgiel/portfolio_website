/*
 *     ppmdiff.c
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: Compares two images and outputs a number that describes how
 *              similar or different they are
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <pnm.h>
#include <a2methods.h>
#include <math.h>

#include "a2plain.h"
#include "a2blocked.h"

FILE *open_up(char *filename);
Pnm_ppm import_ppm_to_array(FILE *input, A2Methods_T methods);
float compute_images(Pnm_ppm first, Pnm_ppm second);
float compare_rgb(Pnm_rgb first, Pnm_rgb second, int first_denom, int second_denom);

int main(int argc, char *argv[])
{
        char *first_name;
        FILE *open_first;
        Pnm_ppm first_ppm;

        char *second_name;
        FILE *open_second;
        Pnm_ppm second_ppm;

        /* default to UArray2 methods */
        A2Methods_T methods = uarray2_methods_plain;
        assert(methods);

        /* default to best map */
        A2Methods_mapfun *map = methods->map_default;
        assert(map);

        if (argc > 3) {
                fprintf(stderr, "Proper usage:\n");
                fprintf(stderr, "./ppmdiff [filename] [filename]\n");
        }

        first_name = argv[1];
        second_name = argv[2];

        open_first = open_up(first_name);
        open_second = open_up(second_name);

        /* One must not be stdin */
        if (open_first == stdin && open_second == stdin) {
                fprintf(stderr, "Can't do two stdins\n");
                exit(1);
        }

        first_ppm = import_ppm_to_array(open_first, methods);
        second_ppm = import_ppm_to_array(open_second, methods);

        float similarity = compute_images(first_ppm, second_ppm);

        Pnm_ppmfree(&first_ppm);
        Pnm_ppmfree(&second_ppm);

        printf("%.4f\n", similarity);

        fclose(open_first);
        fclose(open_second);
        
}

/* Opens a file with the given name (stdin if filename is "-") */
FILE *open_up(char *filename) {
        FILE *opened;
        if (strcmp(filename, "-") == 0) {
                opened = stdin;
        }
        else {
                opened = fopen(filename, "r");
                assert(opened);
        }
        return opened;
}

/* Makes a pnm_ppm from the given FILE stream and using some methods */
Pnm_ppm import_ppm_to_array(FILE *input, A2Methods_T methods)
{
        
        /* Make sure that we are given an actual ppm file */
        Pnm_ppm new_reader = Pnm_ppmread(input, methods);
        assert(new_reader);

        return new_reader;
}

/* Compares the two given Pnm_ppm files */
float compute_images(Pnm_ppm first, Pnm_ppm second)
{
        /* Pull every pixel */
        A2Methods_UArray2 first_data = first -> pixels;
        A2Methods_UArray2 second_data = second -> pixels;
        float running_total = 0;

        /* Arbitrarily use the first image to pull methods */
        const struct A2Methods_T *methods = (first -> methods);

        /* Get the smallest width */
        unsigned smallest_width = first -> width;
        if (second -> width < smallest_width) {
                smallest_width = second -> width;
        }

        /* Get the smallest height */
        unsigned smallest_height = first -> height;
        if (second -> height < smallest_height) {
                smallest_height = second -> height;
        }

        /* Loop through from smallest_width to smallest_height */
        for (unsigned col = 0; col < smallest_width; col++) {
                for (unsigned row = 0; row < smallest_height; row++) {
                        Pnm_rgb first_rgb = methods -> at(first_data, col, 
                                                          row);
                        Pnm_rgb second_rgb = methods -> at(second_data, col, 
                                                           row);

                        running_total += compare_rgb(first_rgb, second_rgb, 
                                    first->denominator, second->denominator);       
                }
        }

        /* Calculate the mean root squared using the given formula */
        return sqrt(running_total / (smallest_width * smallest_height * 3));

}

/* Compares two given rgb pixels and returns the root mean difference */
float compare_rgb(Pnm_rgb first, Pnm_rgb second, int first_denom, 
                  int second_denom)
{
        float root_mean = 0;

        /* Calculate differences for red, green, and blue */
        float red_diff = ((first -> red) / (float)first_denom - 
                          (second -> red) / (float)second_denom);
        red_diff = red_diff * red_diff;

        float green_diff = ((first -> green) / (float)first_denom - 
                          (second -> green) / (float)second_denom);
        green_diff = green_diff * green_diff;

        float blue_diff = ((first -> blue) / (float)first_denom - 
                          (second -> blue) / (float)second_denom);
        blue_diff = blue_diff * blue_diff;

        /* Root mean is the sum of the differences squared */
        root_mean = red_diff + green_diff + blue_diff;

        return root_mean;
}







