#include "a2methods.h"

extern A2Methods_T uarray2_methods_plain; /* functions for normal arrays */
