/*
 *     packer.c
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: Takes a Pnm_ppm_cv filled with component pixels and converts
 *              them to 32 byte code words, which are stored in a sequence
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "except.h"
#include "packer.h"
#include "bitpack.h"
#include "compression_calculations.h"

Except_T Mem_Failed;


void packer_helper(Pnm_ppm_cv component_img, unsigned starting_row, 
                   unsigned starting_col, Seq_T *word_queue);
void pack_values(Seq_T *word_queue, Condensed_pixels condensed);

/*
 * Purpose: To create words using the information in the given component video
 *          image 
 */
Seq_T pack_word(Pnm_ppm_cv component_img, Seq_T word_queue)
{        

        /* Step through every other row and col index */
        for (unsigned row = 0; row < (component_img->height) - 1; row+=2) {
                for (unsigned col = 0; col < (component_img->width) - 1; 
                     col+=2) {
                        /* Go through every block of 2x2 pixels and compress
                         * into a word */
                        packer_helper(component_img, row, col, &word_queue);
                }
        }

        return word_queue;
}

/*
 * Purpose: To retrieve a 2x2 block of pixels using the given starting row and
 *          starting column. These four pixels are then compressed into a
 *          single word and added to the given queue
 */
void packer_helper(Pnm_ppm_cv component_img, unsigned starting_row, 
                   unsigned starting_col, Seq_T *word_queue) 
{
        int k = 0;
        Condensed_pixels condensed;
        A2Methods_UArray2 pixel_array = component_img->cv_pixels;
        Pnm_cv four_pixels[4] = {NULL};

        /* Loop through the four values that will be represented by one word */
        for (unsigned i = starting_row; i <= (starting_row + 1); i++) {
                for (unsigned j = starting_col; j <= (starting_col + 1); j++) {
                        Pnm_cv this_index = (component_img->methods)->
                                            at(pixel_array, j, i);
                        
                        four_pixels[k] = this_index;

                        k = k + 1;
                }
        }

        /* Condense the four given pixels into one condensed struct */
        condensed = compress_cv_pixels(four_pixels[0], four_pixels[1],
                                       four_pixels[2], four_pixels[3]);

        /* Pack the values in this condensed struct into a word, and put that
         * word in the Sequence */
        pack_values(word_queue, condensed);

        /* Free the now-unused condensed pixels */
        free(condensed);
}

/*
 * Purpose: To put the information stored in the given Condensed_pixels into
 *          a 32 bit word, and adds this word to the given Sequence 
 */ 
void pack_values(Seq_T *word_queue, Condensed_pixels condensed) 
{
        uint32_t *word = malloc(sizeof(uint32_t));
        assert(word);

        /* Place the values from condensed into the proper locations in the
         * given word using Bitpack functions */
        *word = 0;

        *word = Bitpack_news(*word, 5, 18, condensed->b);
        *word = Bitpack_news(*word, 5, 13, condensed->c);
        *word = Bitpack_news(*word, 5, 8, condensed->d);

        *word = Bitpack_newu(*word, 9, 23, condensed->a);
        *word = Bitpack_newu(*word, 4, 4, condensed->Pb_avg);
        *word = Bitpack_newu(*word, 4, 0, condensed->Pr_avg);

        /* Add the word to the given queue */
        TRY
                Seq_addhi(*word_queue, word);
        EXCEPT(Mem_Failed)
        END_TRY;
}






