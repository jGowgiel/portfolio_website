/*
 *     unpacker.h
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module uses a given filestream containing code words to 
 *              create a Pnm_ppm_cv with dimensions of the given width and 
 *              height using the data in these code words
 *              
 */


#ifndef UNPACKER_H
#define UNPACKER_H

#include "rgb_to_component.h"

/* Returns a fully allocated Pnm_ppm_cv using values retrieved from the
 * file stream */
extern Pnm_ppm_cv unpack_words(FILE *open, unsigned width, unsigned height);

#endif
