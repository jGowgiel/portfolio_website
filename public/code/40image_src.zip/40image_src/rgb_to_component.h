/*
 *     rgb_to_component.h
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module provides two functions; one to convert a component
 *              video image to rgb, and another to convert from rgb to
 *              component video.
 */



#ifndef RGB_TO_COMPONENT_H
#define RGB_TO_COMPONENT_H

#include "a2methods.h"

#include "pnm.h"

/* An individual component video pixel */
typedef struct Pnm_cv {

        float y, pb, pr;

} *Pnm_cv;

/* A Pnm_ppm that has been modified to contain component video pixels */
typedef struct Pnm_ppm_cv {

        unsigned width, height;
        A2Methods_UArray2 cv_pixels;

        const struct A2Methods_T *methods;

} *Pnm_ppm_cv;

/* This function returns a copy of the original image for which each pixel
 * has been converted to component video space */
extern Pnm_ppm_cv convert_to_component(Pnm_ppm original_image);

/* This function returns a copy of the given component image for which each
 * pixel has been converted to RGB space */
extern Pnm_ppm convert_to_rgb(Pnm_ppm_cv component_image);


#endif
