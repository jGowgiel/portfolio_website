/*
 *     bitpack.c
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module implements a series of functions that allow for
 *              the configuration of a 64 bit word. This module can be used 
 *              with signed or unsigned values. The functions below conform
 *              to the definitions given in the specification
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "bitpack.h"
#include "except.h"

Except_T Bitpack_Overflow = { "Overflow packing bits" };


/*
 * Purpose: To determine whether the given unsigned value can be represented
 *          using "width" bits
 */
bool Bitpack_fitsu(uint64_t n, unsigned width)
{
        if (width <= 0 || width >= 64) {
                return false;
        }
        if ((width == 1 && n == 1) || (width == 1 && n == 0)) {
                return true;
        }
        if ((width == 1 && n != 1) && (width == 1 && n != 0)) {
                return false;
        }

        uint64_t upperbound = 1;

        /* Shifts one bit extra, but then subtracts one to make all bits 1 */
        upperbound = upperbound << width;

        if (n < upperbound) {
                return true;
        }

        else {
                return false;
        }
}

/*
 * Purpose: To determine whether the given signed value can be represented
 *          using "width" bits
 */
bool Bitpack_fitss(int64_t n, unsigned width)
{
        /* Check for edge cases */
        if (width <= 1 || width >= 64) {
                return false;
        }
        if (width == 1 && n == 0) {
                return true;
        }
        if (width == 1 && n != 0) {
                return false;
        }
        if ((width == 2 && n == 1) || (width == 2 && n == 0) || (width == 2 && n == -1)) {
                return true;
        }
        if ((width == 2 && n != 1) && (width == 2 && n != 0) && (width == 2 && n != -1)) {
                return false;
        }

        int64_t upperbound, lowerbound;
        upperbound = lowerbound = 1;

        upperbound = upperbound << (width - 1);

        lowerbound = ~(lowerbound << (width - 1));

        if (n < upperbound && n > lowerbound) {
                return true;
        }
        else {
                return false;
        }
}

/*
 * Purpose: To retrieve the unsigned value stored in the given word that is
 *          located at the given least significant bit (lsb) with the given
 *          width
 */
uint64_t Bitpack_getu(uint64_t word, unsigned width, unsigned lsb)
{
        /* Assertions as defined in the specification */
        assert(width + lsb <= 64);

        uint64_t mask, final;
        
        mask = 1;
        mask = (mask << width) - 1;
        mask = mask << lsb;

        final = mask & word;
        final = final >> lsb;

        return final;
}

/*
 * Purpose: To retrieve the signed value stored in the given word that is
 *          located at the given least significant bit (lsb) with the given
 *          width
 */
int64_t Bitpack_gets(uint64_t word, unsigned width, unsigned lsb)
{
        /* Assertions as defined in the specification */
        assert(width + lsb <= 64);

        uint64_t mask, buffer;
        
        mask = 1; 
        mask = (mask << width) - 1;
        mask = mask << lsb;

        /* Create a mask that will retain only the signed bits */
        uint64_t signed_mask = ~0;
        signed_mask = signed_mask << width;

        /* Follow the same logic as Bitpack_getu */
        buffer = mask & word;
        buffer = buffer >> lsb;

        /* Combine the signed bit mask with the word that has been generated */
        if (buffer >> (width - 1) != 0) {
                buffer = buffer | signed_mask;
        }

        return buffer;

}

/*
 * Purpose: To insert the given unsigned value into the given word, at the
 *          position described by the least significant bit, and the width.
 *          Returns a new word with the value added.
 */
uint64_t Bitpack_newu(uint64_t word, unsigned width, unsigned lsb, uint64_t
                      value)
{
        if (Bitpack_fitsu(value, width)) {
                /* Assertions as defined in the specification */
                assert(width + lsb <= 64);

                uint64_t mask, final;
                mask = 1;

                /* Create a mask that indicates where the value should go */
                mask = (mask << width) - 1;
                mask = mask << lsb;
                mask = ~mask;
                
                /* Shift the value to the right position */
                value = value << lsb;
                
                /* Create the final word by using bitwise operations */
                final = (mask & word) | value;

                return final;
        }
        else {
                /* Raise an exception if the given value will not fit */
                RAISE(Bitpack_Overflow);
                return word;
        }

}

/*
 * Purpose: To insert the given signed value into the given word, at the
 *          position described by the least significant bit, and the width.
 *          Returns a new word, with the value added.
 */
uint64_t Bitpack_news(uint64_t word, unsigned width, unsigned lsb, int64_t 
                      value)
{
        if (Bitpack_fitss(value, width)) {

                /* Assertions as defined in the specification */
                assert(width + lsb <= 64);

                uint64_t mask, final;
                mask = 1;

                mask = (mask << width) - 1;
                mask = mask << lsb;
                mask = ~mask;
                
                value = value << lsb;

                final = (mask & word) | (~mask & value);

                return final;
        }

        else {
                RAISE(Bitpack_Overflow);
                return word;
        }
}


