/*
 *     compression_calculations.c
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module is responsible for creating Condensed_pixels
 *              structs as defined in the header file from a given set of
 *              of four component video pixels, and performing the inverse
 *              operations (from a Condensed_pixels to four component video)
 *              pixels.
 */


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "arith40.h"
#include "compression_calculations.h"


float calculate_avg(float values[], int length);
Condensed_pixels calculate_abcd(Pnm_cv top_left, Pnm_cv top_right, 
                    Pnm_cv bot_left, Pnm_cv bot_right);

Input_pixels extract_y_values(Condensed_pixels values);
float quantize_brightness(float value);

static const float QUANTIZE_RANGE = 0.02;
static const float MAX_BCD = .3;
static const float MIN_BCD = -.3;

/***************************************************************************
 ****************** CONDENSE FOUR PIXELS TO ONE STRUCT *********************
 ***************************************************************************/

/*
 * Purpose: To take the give four Pnm_cv pixels and condense them into a 
 *          single Condensed_pixels struct
 */
Condensed_pixels compress_cv_pixels(Pnm_cv top_left, Pnm_cv top_right, 
                                    Pnm_cv bot_left, Pnm_cv bot_right)
{
        assert(top_left && top_right && bot_left && bot_right);
        Condensed_pixels condensed;
        /* Build out two arrays containing all of the pb and pr 
         * values respectively */
        float pb_values[4] = {top_left->pb, top_right->pb,
                              bot_left->pb, bot_right->pb};

        float pr_values[4] = {top_left->pr, top_right->pr,
                              bot_left->pr, bot_right->pr};


        float new_pb_avg = calculate_avg(pb_values, 4);
        unsigned four_bit_pb = Arith40_index_of_chroma(new_pb_avg);

        float new_pr_avg = calculate_avg(pr_values, 4);
        unsigned four_bit_pr = Arith40_index_of_chroma(new_pr_avg);


        /* Allocate a struct and set the member values */
        condensed = calculate_abcd(top_left, top_right, bot_left, bot_right);
        
        condensed->Pb_avg = four_bit_pb;
        condensed->Pr_avg = four_bit_pr;

        return condensed;
}

/* 
 * Purpose: To calculate the average value of the floats in the given array
 *          of floats with the given length
 */
float calculate_avg(float values[], int length)
{
        assert(length > 0);

        float total = 0;
        for (int i = 0; i < length; i++) {
                total += values[i];
        }
        return total / length;
}

/*
 * Purpose: To calculate the values of a, b, c, and d from the four give pixels
 *          and return them as an allocated Condensed_pixels struct
 */
Condensed_pixels calculate_abcd(Pnm_cv top_left, Pnm_cv top_right, 
                    Pnm_cv bot_left, Pnm_cv bot_right)
{
        Condensed_pixels values = malloc(sizeof(struct Condensed_pixels));
        assert(values);

        /* Calculate the values for a, b, c, and d */
        float new_a = (bot_right->y + bot_left->y + top_right->y + 
                      top_left->y) / 4.0;

        float new_b = (bot_right->y + bot_left->y - top_right->y - 
                    top_left->y) / 4.0;

        float new_c = (bot_right->y - bot_left->y + top_right->y - 
                    top_left->y) / 4.0;

        float new_d = (bot_right->y - bot_left->y - top_right->y + 
                    top_left->y) / 4.0;

        /* Quantize the values */
        new_a = roundf(new_a * (float)511);
        new_b = quantize_brightness(new_b);
        new_c = quantize_brightness(new_c);
        new_d = quantize_brightness(new_d);

        values->a = (unsigned)new_a;
        values->b = (signed)new_b;
        values->c = (signed)new_c;
        values->d = (signed)new_d;

        return values;
}

/*
 * Purpose: To quantize the given brightness value into the acceptable range 
 */
float quantize_brightness(float value) {
        /* Trim values to the lowest and highest acceptable range */
        if (value < MIN_BCD) {
                value = MIN_BCD;
        }

        else if (value > MAX_BCD) {
                value = MAX_BCD;
        }

        return roundf(value / QUANTIZE_RANGE);
}




/***************************************************************************
 ****************** EXPAND ONE STRUCT TO FOUR PIXELS ***********************
 ***************************************************************************/

/* 
 * Purpose: To convert a given struct of condensed values into four pixels 
 */
Input_pixels convert_to_pixels(Condensed_pixels values) 
{
        
        /* Convert the five bit values back to average pb and pr */
        float avg_pb = Arith40_chroma_of_index(values->Pb_avg);
        float avg_pr = Arith40_chroma_of_index(values->Pr_avg);

        Input_pixels new_pixels = extract_y_values(values);

        /* Propagate through the average pb and pr values */
        new_pixels->top_left->pb = avg_pb;
        new_pixels->top_left->pr = avg_pr;

        new_pixels->top_right->pb = avg_pb;
        new_pixels->top_right->pr = avg_pr;

        new_pixels->bot_left->pb = avg_pb;
        new_pixels->bot_left->pr = avg_pr;

        new_pixels->bot_right->pb = avg_pb;
        new_pixels->bot_right->pr = avg_pr;
        
        return new_pixels;
}

/*
 * Purpose: To calculate the Y1, Y2, Y3, and Y4 values for a set of four pixels
 *          from the single given condensed struct
 */
Input_pixels extract_y_values(Condensed_pixels values)
{

        /* Calculate Y1, Y2, Y3, and Y4 from the a b c and d values */
        Input_pixels new_pixels = malloc(sizeof(struct Input_pixels));
        assert(new_pixels);

        /* Allocate every individual pixel */
        new_pixels->top_left = malloc(sizeof(struct Pnm_cv));
        new_pixels->top_right = malloc(sizeof(struct Pnm_cv));
        new_pixels->bot_left = malloc(sizeof(struct Pnm_cv));
        new_pixels->bot_right = malloc(sizeof(struct Pnm_cv));
        assert(new_pixels->top_left && new_pixels->top_right &&
               new_pixels->bot_left && new_pixels->bot_right);

        /* Y1 */
        new_pixels->top_left->y = ((values->a) / (float)511) - 
                                      ((values->b) - (values->c) + 
                                       (values->d)) * QUANTIZE_RANGE;

        /* Y2 */
        new_pixels->top_right->y = ((values->a) / (float)511) - 
                                       ((values->b) + (values->c) - 
                                        (values->d)) * QUANTIZE_RANGE;

        /* Y3 */
        new_pixels->bot_left->y  = ((values->a) / (float)511) + 
                                       ((values->b) - (values->c) - 
                                        (values->d)) * QUANTIZE_RANGE;

        /* Y4 */
        new_pixels->bot_right->y = ((values->a) / (float)511) + 
                                       ((values->b) + (values->c) + 
                                        (values->d)) * QUANTIZE_RANGE;

        return new_pixels;

}






