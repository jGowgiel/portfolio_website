/*
 *     uarray2.c
 *     by Darcy Hinck and Jarod Gowgiel
 *     Homework 3 Part A: UArrayb2
 *
 *     Summary: This implementation of a 2D unboxed array stores memory in 
 *              blocks, rather than in continuous rows of memory. Each block of
 *              size blocksize x blocksize exists as a single UArray, and every
 *              block is stored in an underlying UArray2
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <except.h>
#include <uarray.h>
#include <math.h>
#include "uarray2.h"
#include "uarray2b.h"

/* Struct containing the UArray2b */
struct UArray2b_T {
        int rows;
        int cols;
        int size;
        int blocksize;

        UArray2_T uarray2;
};

/* 
 * Purpose: To allocate the memory for and inititalize the values of a 2D
 *          unboxed array. Raises a CRE if any of the memory allocations fail,
 *          or if the values given are less than or equal to zero
 */
UArray2b_T UArray2b_new(int width, int height, int size, int blocksize)
{
        /* Assert that we are given positive values */
        assert(width > 0 && height > 0 && size > 0 && blocksize > 0);
        struct UArray2b_T *uarray2b = malloc(sizeof(*uarray2b));
        assert(uarray2b != NULL);
        /* Cast to float to avoid integer division, cast back to int to call
         * UArray2_new properly */
        int num_block_cols = (int)ceil((float)width / (float)blocksize);
        int num_block_rows = (int)ceil((float)height / (float)blocksize);

        UArray2_T new_uarray2 = UArray2_new(num_block_cols, num_block_rows,
                                            sizeof(struct UArray_T *));
        assert(new_uarray2 != NULL);
        /* Loop through the UArray2 and allocate a UArray for each index */
        for (int row = 0; row < num_block_rows; row++) {
                for (int col = 0; col < num_block_cols; col++) {
                        UArray_T new_block = UArray_new(blocksize * blocksize,
                                                         size);
                        assert(new_block != NULL);
                        UArray_T *new_block_p = UArray2_at(new_uarray2, col,
                                                           row);
                        assert(UArray2_size(new_uarray2) == 
                               sizeof(struct UArray_T *));
                        *new_block_p = new_block;
                        (void)new_block_p;
                }
        }
        /* Set the proper fields to the proper information */
        uarray2b -> uarray2 = new_uarray2;
        uarray2b -> cols = width;
        uarray2b -> rows = height;
        uarray2b -> size = size;
        uarray2b -> blocksize = blocksize;

        return uarray2b;
}

/*
 * Purpose: To return a new UArray2b with the most efficient blocksize that
 *          will still fit in 64k of memory.
 */
UArray2b_T UArray2b_new_64K_block(int width, int height, int size)
{
        /* If 64 = blocksize * blocksize * size, the blocksize is as follows */
        float blocksize = sqrt(64 / size);

        /* Round the blocksize down, and if less than 1, default to a 
         * blocksize of 1 as per the spec */
        blocksize = floor(blocksize);
        if (blocksize < 1) {
                blocksize = 1;
        }

        UArray2b_T new_uarray2b = UArray2b_new(width, height, size, blocksize);

        return new_uarray2b;
}

/* 
 * Purpose: To return the memory associated with the given 2D array to the
 *          operating system
 */
void UArray2b_free (UArray2b_T *array2b)
{
        /* Figure out how many rows and cols of blocks there are */
        int width = UArray2b_width(*array2b);
        int height = UArray2b_height(*array2b);
        int blocksize = UArray2b_blocksize(*array2b);
        int num_block_cols = (int)ceil((float)width / (float)blocksize);
        int num_block_rows = (int)ceil((float)height / (float)blocksize);

        /* Loop through each block and free the UArray associated 
         * with each one */
        for (int i = 0; i < num_block_rows; i++) {
                for (int j = 0; j < num_block_cols; j++) {
                        UArray_T *to_free = UArray2_at(((*array2b) -> uarray2),
                                                        j, i);
                        UArray_free(to_free);
                }
        }

        UArray2_free(&((*array2b) -> uarray2));
        free(*array2b);

        return;
}

/* 
 * Purpose: To return the width of the given 2D array. Raises a CRE if the 
 *          given pointer is to NULL
 */
int UArray2b_width (UArray2b_T array2b)
{
        assert(array2b != NULL);
        return array2b -> cols;
}

/* 
 * Purpose: To return the height of the given 2D array. Raises a CRE if the 
 *          given pointer is to NULL
 */
int UArray2b_height (UArray2b_T array2b)
{
        assert(array2b != NULL);
        return array2b -> rows;
}

/* 
 * Purpose: To return the size of the given 2D array. Raises a CRE if the 
 *          given pointer is to NULL
 */
int UArray2b_size (UArray2b_T array2b)
{
        assert(array2b != NULL);
        return array2b -> size;
}

/* 
 * Purpose: To return the blocksize of the given 2D array. Raises a CRE if the
 *          given pointer is to NULL
 */
int UArray2b_blocksize(UArray2b_T array2b)
{
        assert(array2b != NULL);
        return array2b -> blocksize;
}

/* 
 * Purpose: To return a pointer to the value in the given UArray2b at the 
 *          given column and row. Raises a CRE if the given index is out of
 *          the range of the given UArray2b, or if the given UArray2b is NULL.
 */
void *UArray2b_at(UArray2b_T array2b, int column, int row)
{
        assert(array2b != NULL);
        assert(column < UArray2b_width(array2b) && column >= 0);
        assert(row < UArray2b_height(array2b) && row >= 0);

        int blocksize = UArray2b_blocksize(array2b);
        UArray_T *block = UArray2_at(array2b -> uarray2, column / blocksize, 
                                     row / blocksize);

        void *value = UArray_at(*block, blocksize * (column % blocksize) + 
                                row % blocksize);
        return value;
}

/*
 * Purpose: To call the given apply function on every element in the given
 *          array2b.
 */
void UArray2b_map(UArray2b_T array2b, void apply(int col, int row, 
                  UArray2b_T array2b, void *elem, void *cl), void *cl)
{
        int num_block_cols = UArray2_width(array2b -> uarray2);
        int num_block_rows = UArray2_height(array2b -> uarray2);
        int total_width = UArray2b_width(array2b);
        int total_height = UArray2b_height(array2b);
        int blocksize = UArray2b_blocksize(array2b);

        for (int block_row = 0; block_row < num_block_rows; block_row++) {
                for (int block_col = 0; block_col < num_block_cols; 
                     block_col++) {

                        /* Loop through blocksize times */
                        for (int elem_row = 0; (elem_row < blocksize) && 
                             ((block_row * blocksize) + elem_row < 
                             total_height); elem_row++) {
                                for (int elem_col = 0; (elem_col < blocksize)
                                     && ((block_col * blocksize) + elem_col 
                                     < total_width); elem_col++) {
                                        /* Call the apply function */
                                        void *element = UArray2b_at(array2b, 
                                                        block_col * blocksize 
                                                        + elem_col, block_row 
                                                        * blocksize + 
                                                          elem_row);
                                        apply(block_col * blocksize + elem_col,
                                              block_row * blocksize + elem_row,
                                              array2b, element, cl);

                                }
                        }
                }
        }
        return;
}

