/*
 *     rgb_to_component.c
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module is used to convert from component to rgb space, 
 *              and vice versa. Each of the two functions from the header
 *              accept a full image of one type, and return a full image of
 *              the other.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "rgb_to_component.h"

static const int TRIM_MULTIPLE = 2;
static const int DEFAULT_DENOMINATOR = 255;


void make_component_image(Pnm_ppm_cv component_image, Pnm_ppm original_image);
void make_cv_pixel(float red, float green, float blue, Pnm_cv cv_pixel);

void make_rgb_image(Pnm_ppm_cv component_image, Pnm_ppm rgb_image);
void make_rgb_pixel(float y, float pb, float pr, Pnm_rgb rgb_pointer);
float quantize_rgb(float value);

/***************************************************************************
 ********************* CONVERT FROM RGB TO COMPONENT ***********************
 ***************************************************************************/


/*
 * Purpose: To convert the given Pnm_ppm to the component video space 
 */
Pnm_ppm_cv convert_to_component(Pnm_ppm original_image)
{
        Pnm_ppm_cv component_image = malloc(sizeof(struct Pnm_ppm_cv));
        assert(component_image && original_image);

        /* Trim width and height to TRIM_MULTIPLE values */
        component_image->width = (original_image->width) - 
                                   (original_image->width % TRIM_MULTIPLE);

        component_image->height = (original_image->height) - 
                                    (original_image->height % TRIM_MULTIPLE);

        component_image->methods = original_image->methods;
        make_component_image(component_image, original_image);

        return component_image;
}

/*
 * Purpose: To update the given component image structure to contain values
 *          that have been converted from the given Pnm_ppm image
 */
void make_component_image(Pnm_ppm_cv component_image, Pnm_ppm original_image)
{
        /* Set the default denominator */
        unsigned denominator = original_image->denominator;
        float red_scaled, green_scaled, blue_scaled;

        A2Methods_UArray2 component_pixels = (component_image->methods) ->
                                             new(component_image->width, 
                                                 component_image->height,
                                                 sizeof(struct Pnm_cv));

        component_image->cv_pixels = component_pixels;

        /* Iterate to each index and convert each pixel to a component pixel */
        for (unsigned row = 0; row < (component_image->height); row++) {
                for (unsigned col = 0; col < (component_image->width); 
                     col++) {

                        Pnm_rgb rgb_pixel = (original_image->methods) -> 
                                             at(original_image->pixels, col, 
                                               row);
                        
                        /* Scale the values using the denominator */
                        red_scaled = (float)(rgb_pixel->red) / 
                                     (float)denominator;
                        green_scaled = (float)(rgb_pixel->green) / 
                                       (float)denominator;
                        blue_scaled = (float)(rgb_pixel->blue) / 
                                      (float)denominator;

                        Pnm_cv cv_pointer = (component_image->methods) ->
                                             at(component_image->cv_pixels,
                                                col, row);

                        /* Place a cv pixel with the given rgb values into the
                         * given cv pixel pointer */
                        make_cv_pixel(red_scaled, green_scaled, blue_scaled, 
                                      cv_pointer);
                }
        }
        (void)component_pixels;
        return;
}

/*
 * Purpose: To make a component video pixel with y, pb, and pr values as
 *          calculated by the equations given in the specification
 */
void make_cv_pixel(float red, float green, float blue, Pnm_cv cv_pointer)
{

        cv_pointer->y = (float)((0.299 * red) + (0.587 * green) + 
                                  (0.114 * blue));
        cv_pointer->pb = (float)((-0.168736 * red) - (0.331264 * green) + 
                                   (0.5 * blue)); 
        cv_pointer->pr = (float)((0.5 * red) - (0.418688 * green) - 
                                   (0.081312 * blue));

        return;
}


/***************************************************************************
 ********************* CONVERT FROM COMPONENT TO RGB ***********************
 ***************************************************************************/

/*
 * Purpose: To convert the given component video image into the RGB space 
 */
Pnm_ppm convert_to_rgb(Pnm_ppm_cv component_image)
{
        /* Allocate the new Pnm_ppm */
        Pnm_ppm rgb_image = malloc(sizeof(struct Pnm_ppm));
        assert(rgb_image);

        /* Copy the correct values into the new RGB image */
        rgb_image->height = component_image->height;
        rgb_image->width = component_image->width;
        rgb_image->methods = component_image->methods;
        rgb_image->denominator = DEFAULT_DENOMINATOR;

        /* Use the given component_image to create an rgb_image */
        make_rgb_image(component_image, rgb_image);
        
        return rgb_image;
}

/*
 * Purpose: To fill the given RGB image with values converted from the 
 *          given component video structure
 */
void make_rgb_image(Pnm_ppm_cv component_image, Pnm_ppm rgb_image)
{
        /* Create a 2D array to store the pixels that we convert */
        A2Methods_UArray2 rgb_pix = (rgb_image->methods)->
                                        new(rgb_image->width, 
                                            rgb_image->height,
                                            sizeof(struct Pnm_ppm));
        rgb_image->pixels = rgb_pix;

        for (unsigned row = 0; row < (rgb_image->height); row++) {
                for (unsigned col = 0; col < (rgb_image->width); col++) {
                        /* Pointer to the cv pixel we want to convert */
                        Pnm_cv comp_pixel = (component_image->methods)
                                                ->at(component_image->
                                                        cv_pixels, col, row);
                        
                        Pnm_rgb rgb_pointer = (rgb_image->methods)->
                                                at(rgb_image->pixels, col, 
                                                   row);

                        /* Convert and place the given y, pb and pr values into
                         * the given rgb pointer */
                        make_rgb_pixel(comp_pixel->y,comp_pixel->pb, 
                                       comp_pixel->pr, rgb_pointer);

                }
        }

}

/*
 * Purpose: To allocate an RGB pixel with values that have been converted from
 *          the given y, pb and pr values
 */
void make_rgb_pixel(float y, float pb, float pr, Pnm_rgb rgb_pointer)
{
        assert(rgb_pointer);

        /* Calculate the red, green and blue values */
        float raw_red = y + (1.402 * pr);
        float raw_green = y - (.344136 * pb) - (.714136 * pr);
        float raw_blue = y + (1.772 * pb);

        /* Quantize the values into an acceptable range */
        raw_red = quantize_rgb(raw_red);
        raw_green = quantize_rgb(raw_green);
        raw_blue = quantize_rgb(raw_blue);

        rgb_pointer->red = (unsigned)roundf((raw_red));
        rgb_pointer->green = (unsigned)roundf((raw_green));
        rgb_pointer->blue = (unsigned)roundf((raw_blue));

        return;
}

/*
 * Purpose: To quantize the given float into an acceptable range
 */
float quantize_rgb(float value) {

        value = value * (float)DEFAULT_DENOMINATOR;

        /* Place the values inside of the acceptable range */
        if (value > (float)DEFAULT_DENOMINATOR) {
                value = (float)DEFAULT_DENOMINATOR;
        }
        else if (value < 0) {
                value = 0;
        }

        return value;
}




