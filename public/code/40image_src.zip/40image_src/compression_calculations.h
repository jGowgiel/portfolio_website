/*
 *     compression_calculations.h
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: The header file for compression_calculations. This module
 *              provides just two functions: compress_cv_pixels that takes in
 *              four component video pixels and returns a Condensed_pixels,
 *              and the function convert_to_pixels which takes a 
 *              Condensed_pixels and returns a struct of four component pixels
 */



#ifndef COMPRESSION_CALCULATIONS_H
#define COMPRESSION_CALCULATIONS_H

#include "rgb_to_component.h"

/* The Condensed_pixels struct contains the individual values that will
 * eventually be used to create a "word" */
typedef struct Condensed_pixels {

        unsigned a, Pb_avg, Pr_avg;
        signed b, c, d;

} *Condensed_pixels;

/* The input pixels struct contains the four pixels that will be converted
 * into a Condensed_pixels, or from a Condensed_pixels */
typedef struct Input_pixels {

        Pnm_cv top_left, top_right, bot_left, bot_right;

} *Input_pixels;


/* This function returns a Condensed_pixels struct that contains the 
 * data calculated from the four given pixels */
extern Condensed_pixels compress_cv_pixels(Pnm_cv top_left, Pnm_cv top_right, 
                                           Pnm_cv bot_left, Pnm_cv bot_right);

/* This function returns four pixels stored as an Input_pixels struct using
 * the data stored in the given Condensed_pixels */
extern Input_pixels convert_to_pixels(Condensed_pixels values);



#endif
