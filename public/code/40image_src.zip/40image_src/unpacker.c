/*
 *     unpacker.c
 *     by Saad Mazhar and Jarod Gowgiel
 *     Homework 4
 *
 *     Summary: This module reads in values from a given filestream, and
 *              unpacks those words into a Pnm_ppm_cv which is returned back.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "except.h"
#include "assert.h"
#include "a2methods.h"

#include "a2plain.h"
#include "bitpack.h"
#include "compression_calculations.h"
#include "unpacker.h"


void place_words(Pnm_ppm_cv new_image, FILE* input);
Condensed_pixels unpack_values(uint64_t word);
void place_four_pix(Pnm_ppm_cv new_image, Input_pixels to_place, 
                    unsigned start_col, unsigned start_row);
void copy_values(Pnm_cv copy_into, Pnm_cv copy_from);


static const unsigned WORD_BYTES = 4;

Except_T File_Too_Short;

/*
 * Purpose: To pull words from the given filestream and use them to populate
 *          a Pnm_ppm_cv structure with the given width and height
 */
Pnm_ppm_cv unpack_words(FILE *open, unsigned width, unsigned height) 
{
        /* Create a Pnm_ppm_cv with the given values */
        Pnm_ppm_cv cv_image = malloc(sizeof(struct Pnm_ppm_cv));
        assert(cv_image);

        A2Methods_T new_methods = uarray2_methods_plain;
        assert(new_methods);

        A2Methods_UArray2 new_pixels = new_methods->new(width, height, 
                                                      sizeof(struct Pnm_cv));

        /* Set member variables of the component video image */
        cv_image->width = width;
        cv_image->height = height;
        cv_image->methods = new_methods;

        cv_image->cv_pixels = new_pixels;

        /* Extract values from the file stream and put them in the given
         * component video image in row-major order */
        place_words(cv_image, open);

        return cv_image;
}


/*
 * Purpose: To use words taken from the given file stream to extract the
 *          values of a, b, c, d, pb, and pr into the given Pnm_ppm_cv
 */
void place_words(Pnm_ppm_cv new_image, FILE* input)
{
        /* Read each value from the input */
        Condensed_pixels temp_condensed;
        Input_pixels temp_pixels;

        /* Stride through every other row and col in the given image */
        for (unsigned row = 0; row < (new_image->height); row = row + 2) {
                for (unsigned col = 0; col < (new_image->width); 
                     col = col + 2) {

                        /* Pull values from the input one byte at a time */
                        uint64_t int_temp = 0;
                        for (int pos = WORD_BYTES - 1; pos >= 0; pos--) {
                                char temp = getc(input);

                                if (feof(input)) {
                                        RAISE(File_Too_Short);
                                }

                                int32_t sixfour_temp = Bitpack_getu(temp, 8, 0);

                                int_temp = Bitpack_newu(int_temp, 8, pos * 8, sixfour_temp);
                        }

                        temp_condensed = unpack_values(int_temp);

                        /* Extract four pixels from the newly-unpacked
                         * condensed pixels struct */
                        temp_pixels = convert_to_pixels(temp_condensed);

                        /* Use the extracted values to fill in a 2x2 block at
                         * [col, row] */
                        place_four_pix(new_image, temp_pixels, col, row);

                        /* Free the now-unused memory */
                        free(temp_pixels);
                        free(temp_condensed);
                }
        }
}

/*
 * Purpose: To pull the proper values from the correct indeces in the given
 *          32 bit word and produce a Condesned_pixels struct using those
 *          values
 */
Condensed_pixels unpack_values(uint64_t word) {

        Condensed_pixels new_pixels = malloc(sizeof(struct Condensed_pixels));
        assert(new_pixels);

        /* Pull out the proper values from the packed word */
        new_pixels->b = Bitpack_gets(word, 5, 18);
        new_pixels->c = Bitpack_gets(word, 5, 13);
        new_pixels->d = Bitpack_gets(word, 5, 8);

        new_pixels->a = Bitpack_getu(word, 9, 23);
        new_pixels->Pb_avg = Bitpack_getu(word, 4, 4);
        new_pixels->Pr_avg = Bitpack_getu(word, 4, 0);

        return new_pixels;
}

/*
 * Purpose: To place the four given pixels into the given image starting at
 *          the given row and column
 */
void place_four_pix(Pnm_ppm_cv new_image, Input_pixels to_place, 
                    unsigned start_col, unsigned start_row)
{
        /* Retrieve pointers to the pixels that will be modified */

        /* TOP LEFT PIXEL */
        Pnm_cv first = new_image->methods->at(new_image->cv_pixels, 
                                                start_col, start_row);
        /* TOP RIGHT PIXEL */
        Pnm_cv second = new_image->methods->at(new_image->cv_pixels, 
                                                start_col + 1, start_row);
        /* BOTTOM LEFT PIXEL */
        Pnm_cv third = new_image->methods->at(new_image->cv_pixels, 
                                                start_col, start_row + 1);
        /* BOTTOM RIGHT PIXEL */
        Pnm_cv fourth = new_image->methods->at(new_image->cv_pixels, 
                                                start_col + 1, start_row + 1);

        /* Copy values from the given pixels into the image */
        copy_values(first, to_place->top_left);
        copy_values(second, to_place->top_right);
        copy_values(third, to_place->bot_left);
        copy_values(fourth, to_place->bot_right);

        /* Free the now-copied values that were passed in */
        free(to_place->top_left);
        free(to_place->top_right);
        free(to_place->bot_left);
        free(to_place->bot_right);

        return;
}

/*
 * Purpose: To copy the values from the second Pnm_cv into the first, to
 *          prevent double allocation of memory within the Pnm_ppm_cv
 */
void copy_values(Pnm_cv copy_into, Pnm_cv copy_from)
{
        copy_into->y = copy_from->y;
        copy_into->pb = copy_from->pb;
        copy_into->pr = copy_from->pr;
}

