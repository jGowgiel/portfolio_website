// Name:        Jarod Gowgiel (jgowgi01)
// Assignment:  Comp 15 Proj 2 - Gerp
// Date:        December 1 2016 (rabbit rabbit!)
//
// Purpose:     Holds the implementation of the functions outlined in 
//              TryIndex.h



#include <iostream>
#include <string>


#include "TryNode.h"
#include "TryIndex.h"

using namespace std;

// Purpose: To construct an empty TryIndex
// Arguments: None
// Returns: None
TryIndex::TryIndex() {
    root = new TryNode;
}

// Purpose: To return memory to the system
// Arguments: None
// Returns: None
TryIndex::~TryIndex() {
    delete root;
}


// Purpose: To add the given word to the Trie with the given path and line
//          number.
// Arguments: A word to add, the path to the file in which it occurs, and the
//            line number on which it occurs in that file
// Returns: None
void TryIndex::add_word(string word, string path, int line_num) {
    TryNode *current = root;
    TryNode *next;
    int letter_pos = 0;
    int word_len = word.size()-1;
    while (letter_pos <= word_len) {
        next = current->has_child(word[letter_pos]);
        // The letter exists as a child
        if (next != NULL and letter_pos != word_len) {
            current = next;
            letter_pos++;
        }
        else {                  // The rest of the word must be added
            if (next != NULL) {
                next->make_eow();
                next->add_occurrence(path, line_num);
                return;
            }
            // Define the new TryNode to insert
            TryNode *to_add = new TryNode;
            to_add->setCharacter(word[letter_pos]);
            if (letter_pos == word_len) {  // This sets the end of word stuff
                to_add->add_occurrence(path, line_num);
                to_add->make_eow();
            }
            current->add_child(to_add, word[letter_pos]);
            current = (current->has_child(word[letter_pos]));
            letter_pos++;
        }}}

// Purpose: To check if the given word is in the Trie
// Arguments: A word to check for
// Returns: A bool indicating whether the word was found
bool TryIndex::has_word(string word) {
    TryNode *current = root;
    int letter_pos = 0;
    int word_len = word.size();

    while (letter_pos <= word_len) {
        // Check for end of word
        if (letter_pos == word_len) {
            if (current->is_eow()) {
                all_occurrences(current);
                return true;
            }
            else {
                return false;
            }
        }
        // The child exists, the word is not done, the search continues
        if (current->has_child(word[letter_pos]) != NULL) {
            current = current->has_child(word[letter_pos]);
            letter_pos++;
        }

        else {
            return false;
        }
    }
    // This line should never be reached. All cases are handled above
    return false;
}

// Purpose: To print out all the occurrences of the given TryNode
// Arguments: A TryNode to print all occurrences from
// Returns: None
void TryIndex::all_occurrences(TryNode *print_from) {
    print_from->print_occurrences();
}



