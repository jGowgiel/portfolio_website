// Name:        Jarod Gowgiel (jgowgi01)
// Assignment:  Comp 15 Proj 2 - Gerp
// Date:        December 1 2016 (rabbit rabbit!)
//
// Purpose:     To run the whole shebang. This file inteprets command line
//              inputs and properly searches and outputs information.



#include <iostream>

#include <cstdlib>

#include "WordIndex.h"

using namespace std;

void print_error();

void print_end_note();

int main(int argc, char *argv[]) {
    if (argc!= 2) {
        print_error();
    }
    WordIndex test;
    string path = argv[1];
    test.build_index(path);

    string search = "";
    while ((search != "@q" and search != "@quit") and !cin.eof()) {
        cout << "Query? ";
        cin >> search;
        // End of file catch
        if (cin.eof()) {
            search.clear();
        }
        else if (search == "@i" or search == "@insensitive") {
            // Pull the next word and perform an insensitive search
            cin >> search;
            test.search_index_insensitive(search);
            // Catch for "@i @q" functionality
            if (search == "@q" or search == "@quit") {
                search.clear();
            }
        }
        else {
            test.search_index(search);
        }
        
    }
    print_end_note();
}

// Purpose: To print the proper error message
// Arguments: None
// Returns: None
void print_error() {
    cerr << "Usage: ./gerp directory" << endl;
    cerr << "            where: directory is a valid directory"<< endl;
    exit(EXIT_FAILURE);
}

// Purpose: To print the last note
// Arguments: None
// Returns:  None
void print_end_note() {
    cout << endl;
    cout << "Goodbye! Thank you and have a nice day." << endl;
}




