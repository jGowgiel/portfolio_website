



#ifndef TRY_NODE_H
#define TRY_NODE_H

#include <vector>

class TryNode {

public:
    // Constructor and Destructor
    TryNode();
    // Overloaded to insert new character easily
    TryNode(char set_character);
    ~TryNode();

    // Changes the current character of the word
    void setCharacter(char new_character);

    // Returns the current character
    char current_character();

    // Makes end_of_word true 
    void make_eow();

    // Returns the state of end_of_word
    bool is_eow();

    // Adds a new File_Occurence with a given path and line num
    // If the file already exists, simply add the line num to that 
    // FileOccurrence's vector of line_nums
    void add_occurrence(std::string path, int line_num);

    // Print all occurences in the given Node
    void print_occurrences();

    // Find if this TryNode has a given char as a child, returning a pointer
    // to this child if it exists
    TryNode *has_child(char c);

    // Add a char as a child to the current TryNode
    void add_child(TryNode *to_add, char index_char);

    

private:

    // Prints the line at the given number in the given file path
    void print_line(std::string path, int line_num);

    // This struct contains the path to the file in which the word occurs
    // and the line numbers in that file on which the word occurs
    struct FileOccurrence {
        std::string file_path;

        std::vector<int> line_nums;
    };

    // This set holds all of the files in which the word that terminates
    // with this char occurs
    std::vector<FileOccurrence> files;

    // The character this Node represents
    char this_character;
    // Whether this character is or is not the end of a word
    bool end_of_word;

    // An array of TryNode children pointers that can be accessed in
    // constant time
    static const int ASCII_CHARS = 128;
    // STATIC ARRAY OF LENGTH (MAX ASCII)
    TryNode *children[ASCII_CHARS];

};


#endif