// Name:        Jarod Gowgiel (jgowgi01)
// Assignment:  Comp 15 Proj 2 - Gerp
// Date:        December 1 2016 (rabbit rabbit!)
//
// Purpose:     This file represents the actual Trie, holding a pointer to the
//              root and allowing for words to be added and searched for.



#ifndef TRY_INDEX_H
#define TRY_INDEX_H


#include "TryNode.h"


class TryIndex {

public:
    // Constructor and Destructor
    TryIndex();
    ~TryIndex();

    // Insert a given word into the trie, with a path and line number that
    // the given word occurs on
    void add_word(std::string word, std::string path, int line_num);

    // Search for a given word in the trie
    bool has_word(std::string word);


private:

    void all_occurrences(TryNode *print_from);
    
    TryNode *root;

};


#endif