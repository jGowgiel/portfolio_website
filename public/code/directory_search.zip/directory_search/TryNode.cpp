// Name:        Jarod Gowgiel (jgowgi01)
// Assignment:  Comp 15 Proj 2 - Gerp
// Date:        December 1 2016 (rabbit rabbit!)
//
// Purpose:     This file holds the implementation of the functions outlined
//              in TryNode.h



#include <vector>
#include <iostream>
#include <fstream>
#include <string>

#include "TryNode.h"

using namespace std;

// Purpose: To inititalize a new empty Node
// Arguments: None
// Returns: None
TryNode::TryNode() {
    // Initialize values
    end_of_word = false;
    for (int i = 0; i < ASCII_CHARS; i++) {
        children[i] = NULL;
    }
    
}

// Purpose: To initialize a new TryNode with a given character
// Arguments: A character to set this Node equal to
// Returns: None
TryNode::TryNode(char set_character) {
    end_of_word = false;

    for (int i = 0; i < ASCII_CHARS; i++) {
        children[i] = NULL;
    }
    setCharacter(set_character);
}

// Purpose: To return memory to the operating system
// Arguments: None
// Returns: None
TryNode::~TryNode() {
    for (int i = 0; i < ASCII_CHARS; i++) {
        delete children[i];
    }
}


// Purpose: To update the character stored as a private variable
// Arguments: A character to change the value to
// Returns: None
void TryNode::setCharacter(char new_character) {
    this_character = new_character;
}

// Purpose: To return the character that this Node represents
// Arguments: None
// Returns: This Node's char
char TryNode::current_character() {
    return this_character;
}


// Purpose: To modify the end_of_word variable for this Node
// Arguments: None
// Returns: None
void TryNode::make_eow() {
    end_of_word = true;
}

// Purpose: Returns the state of end_of_word for this Node
// Arguments: None
// Returns: The bool end_of_word
bool TryNode::is_eow() {
    return end_of_word;
}


// Purpose: To add an occurrence to the given Node
// Arguments: A path and a line_num on which the word occurs
// Returns: None
void TryNode::add_occurrence(string path, int line_num) {
    
    int vect_size = files.size();

    if (vect_size > 0) {
        // If the path already exists, add just a line
        if (files[vect_size-1].file_path == path) {
            int lines_len = files[vect_size-1].line_nums.size();
            
            if (files[vect_size-1].line_nums[lines_len-1] == line_num) {
                // Prevents adding of duplicate line numbers
                return;
            }
            files[vect_size-1].line_nums.push_back(line_num);

            // Each unique path can occur only once, so returning from here
            // saves on time
            return;
        }
    }
    // If no path was found, a new FileOccurrence needs to be added
    FileOccurrence new_occurrence;
    new_occurrence.file_path = path;
    new_occurrence.line_nums.push_back(line_num);

    // Push new_occurrence to the list of files that have this word
    files.push_back(new_occurrence);
    return;
}


// Purpose: To return the child at the integer index c
// Arguments: A char to find in the array of children
// Returns: A pointer to the child Node, or NULL if there is no Node at the
//          index.
TryNode *TryNode::has_child(char c) {
    return children[(int)c];
}

// Purpose: To add a child to the current Node
// Arguments: A pointer to a Node to add, and a char index to add it at
// Returns: None
void TryNode::add_child(TryNode *to_add, char index_char) {
    // Change the given char to the child provided
    children[(int)index_char] = to_add;
    return;
}

// Purpose: To print out all occurrences in the current Node
// Arguments: None
// Returns: None
void TryNode::print_occurrences() {
    int num_occurences = files.size();
    for (int i = 0; i < num_occurences; i++) {
        string path = files[i].file_path;
        int num_lines = files[i].line_nums.size();
        for (int j = 0; j < num_lines; j++) {
            cout << path << ":" << files[i].line_nums[j];
            print_line(path, files[i].line_nums[j]);
        }
    }
}

// Purpose: To print out the line at the given line_num in the given path
// Arguments: A path to the file and the line number in that file
// Returns: None
void TryNode::print_line(string path, int line_num) {
    ifstream pull_from;
    pull_from.open(path);
    string line;
    int counter = 0;
    while (counter < line_num) {
        getline(pull_from, line);
        counter++;
    }
    cout << ": " << line << endl;
}

