// Name:        Jarod Gowgiel (jgowgi01)
// Assignment:  Comp 15 Proj 2 - Gerp
// Date:        December 1 2016 (rabbit rabbit!)
//
// Purpose:     This file contains the implementation of the functions
//              outlined in WordIndex.h



#include <iostream>
#include <fstream>
#include <sstream>

#include <string>
#include <ctype.h>

#include "FSTree.h"
#include "DirNode.h"
#include "WordIndex.h"

using namespace std;


// Purpose: To construct a new, empty TryIndex
// Arguments: None
// Returns: None
WordIndex::WordIndex() {
    index = new TryIndex;
}

// Purpose: To return the memory to the system
// Arguments: None
// Returns: None
WordIndex::~WordIndex() {
    delete index;
}


// Purpose: To build an FSTree of the director given
// Arguments: A string to build the FSTree from
// Returns: None
void WordIndex::build_index(string directory_path) {
    // Define an FSTree of the given directory
    FSTree directory(directory_path);
    DirNode *root = directory.getRoot();

    // Correctly format the starting path
    int path_len = directory_path.length();
    while (directory_path[path_len-1] != '/') {
        directory_path.pop_back();
        path_len--;
    }

    // Put every word into the index
    recursively_build(root, directory_path);
    
}

// Purpose: To add the words in every file in the tree defined by the DirNode
//          to the Trie
// Arguments: A DirNode to build from and a path to the directory
// Returns: None
void WordIndex::recursively_build(DirNode *to_build, string path) {

    // Update the current path by appending the current directory name and a 
    // "/" as directed in the documentation.
    path += to_build->getName();
    path += "/";

    // Recurse through available sub-directories. If there are none, this loop
    // will not run.
    int num_sub_dirs = to_build->numSubDirs();

    for (int i = 0; i < num_sub_dirs; i++) {
        recursively_build(to_build->getSubDir(i), path);
    }
    
    // Now, print all files in the current sub-directory. If there are no 
    // files, the loop will not run.
    int num_files = to_build->numFiles();
    for (int i = 0; i < num_files; i++) {        
        add_to_try(path+to_build->getFile(i));
    }
}


// Purpose: To add all the words in the given file path to the Trie
// Arguments: A path to open and add words from
// Returns: None
void WordIndex::add_to_try(string path) {
    ifstream input;
    input.open(path);
    string line, word;
    int num_line = 1;

    while (!input.eof()) {
        
        line.clear();
        // Functionality; getline(stream, destination)
        getline(input, line);

        // Define a stringstream to take out individual words
        stringstream in_line;
        in_line << line;
        
        while (!in_line.eof()) {
            word.clear();
            in_line >> word;
            int word_len = word.length();
            if (word_len > 0) {
                index->add_word(word, path, num_line);
            }            
        }
        in_line.clear();
        num_line++;
    }
}


// Purpose: To search the Trie for the given query
// Arguments: A query to search for
// Returns: None
void WordIndex::search_index(string query) {
    bool found = index->has_word(query);
    if (query != "@q" and query != "@quit") {
        if (found == false) {
            cout << query; 
            cout << " Not Found. Try with @insensitive or @i." << endl;
        }
    }
}

// Purpose: To search for the given query without regard for case
// Arguments: A string to search for
// Returns: None
void WordIndex::search_index_insensitive(string query) {
    int word_len = query.length();
    int num_found = 0;
    string lower_word = "";
    
    // Convert to lower case
    for (int i = 0; i < word_len; i++) {
        lower_word.push_back(tolower(query[i]));
    }

    // Begin recursion
    if (index->has_word(lower_word)) {
        num_found++;
    }
    toggle_search(lower_word, 0, word_len, num_found);

    if (num_found == 0) {
        cout << query << " Not Found." << endl;
    }
}

// Purpose: To call a search on every possible version of a word with varying
//          cases.
// Arguments: A word to search for, the position in this word, the length of
//            the word, and a passed-by-reference int that holds how many
//            instances of the word were found.
// Returns: None
void WordIndex::toggle_search(string word, int position, int len, 
                              int &num_found) {
    // I think I finally get how recursion can be beautiful. I'm very proud 
    // of this solution
    
    while (position < len) {

        toggle_search(word, position+1, len, num_found);

        word[position] = toupper(word[position]);

        if (index->has_word(word)) {
            num_found++;
        }

        position++;
    }
}






