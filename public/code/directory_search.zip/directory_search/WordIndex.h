// Name:        Jarod Gowgiel (jgowgi01)
// Assignment:  Comp 15 Proj 2 - Gerp
// Date:        December 1 2016 (rabbit rabbit!)
//
// Purpose:     This file contains the necessary functions to strip words
//              from a directory and add them to a try. As well, this class
//              is responsible for searching the Trie that it has built.



#ifndef WORD_INDEX_H
#define WORD_INDEX_H

#include "TryIndex.h"
#include "DirNode.h"



class WordIndex {

public:

    // Constructor and Destructor
    WordIndex();
    ~WordIndex();

    // Build a Try using filestreams. Calls recursively_build()
    void build_index(std::string directory_path);

    
    // Call a search on the Try
    void search_index(std::string query);

    void search_index_insensitive(std::string query);

private:

    // Recursively build the TryIndex
    void recursively_build(DirNode *to_build, std::string directory_path);
    // Adds the given path to the try
    void add_to_try(std::string path);

    // Recursively runs a search on the given word, with every possible
    // variation of capitalization
    void toggle_search(std::string word, int position, int len, 
                       int &num_found);


    TryIndex *index;

};


#endif